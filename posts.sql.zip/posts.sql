-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2020 at 03:59 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `posts`
--

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL,
  `post_title` text NOT NULL,
  `post_description` varchar(5000) NOT NULL,
  `post_excerpt` varchar(5000) NOT NULL,
  `post_image` text NOT NULL,
  `isactive` text NOT NULL,
  `author` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`post_id`, `post_title`, `post_description`, `post_excerpt`, `post_image`, `isactive`, `author`) VALUES
(12, 'post One', ' this is the body of post 1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum condimentum ligula nec blandit. Phasellus consequat turpis leo, vel eleifend lectus aliquet quis. Quisque varius consectetur sapien id posuere. Quisque eu mauris suscipit, consectetur lectus et, egestas turpis. Nullam pharetra est quis mollis efficitur. Mauris ullamcorper eget ex et lacinia. Aliquam nulla est, laoreet sed eros sed, imperdiet ultricies nibh. Donec eu sapien pharetra, ullamcorper augue nec, sollicitudin nisi. Integer ullamcorper mi dolor, sed convallis ex molestie ut. Fusce hendrerit orci vel diam lobortis, vitae ultrices felis pulvinar. In hac habitasse platea dictumst. Pellentesque in sapien ornare, laoreet nibh sed, pharetra enim. Curabitur sollicitudin ligula non diam sagittis, vitae feugiat libero iaculis. Donec a mi tincidunt, iaculis ante vel, posuere ipsum. Mauris luctus nisi eget nisl ullamcorper finibus quis sit amet ligula.', 'icons-03.png', 'no', 5),
(13, 'post two', ' this is the body of post 2', 'Sed mauris nulla, tincidunt sed molestie vel, mollis eu mi. Suspendisse potenti. Phasellus et mi sed velit convallis ullamcorper vel nec libero. Vivamus lobortis diam vitae orci consequat maximus. Phasellus vehicula quam sit amet lorem euismod, quis euismod tortor pharetra. Quisque eu libero vitae arcu iaculis congue in vitae neque. Vivamus rutrum dictum magna eget eleifend.Sed sed suscipit erat, vitae pellentesque nulla. Donec vel odio velit. Nulla et feugiat odio. Sed ut facilisis felis. In mattis diam magna, eu elementum metus vulputate a. Donec sollicitudin, est eget posuere rhoncus, leo arcu bibendum odio, sed facilisis est neque sed neque. Sed a magna tincidunt, fermentum quam sed, lacinia nisi. Cras mattis dapibus turpis, sit amet pharetra ipsum. Donec enim magna, scelerisque sit amet pharetra ut, volutpat at mauris. Donec eu pellentesque libero. Vivamus molestie ullamcorper justo, vel egestas neque consequat vitae. Fusce pretium bibendum bibendum.', '555 Shopper-01.png', 'yes', 1),
(16, 'Post Test', 'This is the description of post test', 'nothing to write i have asked the content writer to write something for me for this post please so i will update the text as i will get the idea.', 'Current-Deals-Chair.png', 'yes', 5);

-- --------------------------------------------------------

--
-- Table structure for table `post_comments`
--

CREATE TABLE `post_comments` (
  `comment_id` int(11) NOT NULL,
  `user_id` int(20) NOT NULL,
  `post_id` int(20) NOT NULL,
  `comment` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `post_comments`
--

INSERT INTO `post_comments` (`comment_id`, `user_id`, `post_id`, `comment`, `date`) VALUES
(3, 5, 12, 'this is testing comment please check', '2020-11-05'),
(4, 5, 12, 'this is testing comment please check', '2020-11-18'),
(5, 1, 12, 'this is testing comment please check', '2020-11-19'),
(20, 5, 12, 'this is testing', '2020-11-10'),
(21, 5, 12, 'this is testing', '2020-11-06'),
(25, 0, 16, 'ajax', '0000-00-00'),
(26, 0, 16, 'ajax', '0000-00-00'),
(27, 0, 16, 'ajax commment try', '0000-00-00'),
(28, 5, 16, 'ajax hit', '0000-00-00'),
(29, 5, 16, 'comment 2', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `user_role` text DEFAULT NULL,
  `approve` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `user_role`, `approve`) VALUES
(1, 'admin', 'irfankareem@ymail.com', 'admin', 'Admin', ''),
(5, 'test', 'test@123.com', '123', '', 'Yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `post_comments`
--
ALTER TABLE `post_comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `post_comments`
--
ALTER TABLE `post_comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
